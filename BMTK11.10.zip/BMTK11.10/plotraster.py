from bmtk.analyzer.spike_trains import plot_raster, plot_rates

plot_raster(config_file='simulation_config.json')
