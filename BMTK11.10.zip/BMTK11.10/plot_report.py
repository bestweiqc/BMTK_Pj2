from bmtk.analyzer.cell_vars import plot_report

plot_report(config_file='simulation_config.json', node_ids=[0,1,65,91,92,93,94,95])
